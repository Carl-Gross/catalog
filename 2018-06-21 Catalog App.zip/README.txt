To run the project from scratch:
1) Run db_setup.py to create the database and set up the tables
2) Run populate_catalog.py to create the list of manufacturers
3) Run application.py to start the server
4) Use a browser to navigate to localhost:5000
5) Sign in to access the ability to add, edit, or delete models